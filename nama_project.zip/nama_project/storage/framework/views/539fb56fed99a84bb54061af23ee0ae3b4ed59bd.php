<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
 integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous"  textColor="white">

<?php $__env->startSection('main'); ?>
<div id="siswa">
      <h2>Detail Siswa</h2>

      <table class="table table-striped">
        <tr>
        <center>
            <img class="rounded" src="<?php echo e(asset('images/'.$siswa->avatar)); ?>" width="300px" height="auto">
        </center>
        </tr>
        <br>
        <tr>
            <th>NISN</th>
            <td><?php echo e($siswa->nisn); ?></td>
        </tr>
        <tr>
            <th>Nama</th>
            <td><?php echo e($siswa->nama_siswa); ?></td>
        </tr>
        <tr>
            <th>Tanggal Lahir</th>
            <td><?php echo e($siswa->tanggal_lahir); ?></td>
        </tr>
        <tr>
            <th>Kelas</th>
            <td><?php echo e(!empty($siswa->kelas->nama_kelas) ?
                        $siswa->kelas->nama_kelas : '-'); ?></td>
        </tr>
        <tr>
            <th>Jenis Kelamin</th>
            <td><?php echo e($siswa->jenis_kelamin); ?></td>
        </tr>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nama_project\resources\views/siswa/show.blade.php ENDPATH**/ ?>