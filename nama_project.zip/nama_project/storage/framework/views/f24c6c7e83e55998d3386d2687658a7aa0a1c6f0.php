<?php $__env->startSection('main'); ?>
<div id="guru">
      <h2>Guru</h2>

     <?php if(!empty($guru_list)): ?>
     <table class="table table-striped">
    <tr>
        
        <th>NIP</th>
        <th>Nama</th>
        <th>Tanggal Lahir</th>
        <th>Jenis kelamin</th>
        <th>Action</th>
    </tr>

        <tbody>
            <?php $__currentLoopData = $guru_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $guru): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                
                <td><?php echo e($guru->id); ?></td>
                <td><?php echo e($guru->nama_guru); ?></td>
                <td><?php echo e($guru->tanggal_lahir); ?></td>
                <td><?php echo e($guru->jenis_kelamin); ?></td>
                <td><a class="btn btn-success btn-sm" href="<?php echo e(url('guru/' . $guru->id)); ?>">Detail</a></td>
                <td><a class="btn btn-warning btn-sm" href="<?php echo e(url('guru/' . $guru->id . '/edit')); ?>">Edit</a></td>
                <td><a class="btn btn-danger btn-sm" href="<?php echo e(url('guru/' . $guru->id . '/delete')); ?>">Delete</a></td>

                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
        
    <?php else: ?>
        <p>Tidak ada data guru.</p>
    <?php endif; ?>

</div>
  </tbody>
</table>
    <a href="<?php echo e(url('guru/create')); ?>" class="btn btn-primary">Tambah</a>
<br>
<br>
<br>
<br>
<br>
<br>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
    <div id="footer">
        <p>&copy; 2019 Belajar_Laravel</p>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nama_project\resources\views/guru/guru.blade.php ENDPATH**/ ?>