<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
 integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous"  textColor="white">

<?php $__env->startSection('main'); ?>
<div id="walikelas">
      <h2>Detail Wali Kelas</h2>

      <table class="table table-striped">
        <tr>
        <center>
            <img class="rounded" src="<?php echo e(asset('images/'.$walikelas->avatar)); ?>" width="300px" height="auto">
        </center>
        </tr>
        <tr>
            <th>Nama Kelas</th>
            <td><?php echo e(!empty($walikelas->kelas->nama_kelas) ?
                        $walikelas->kelas->nama_kelas : '-'); ?></td>
        </tr>

        <tr>
            <th>Nama Kelas</th>
            <td><?php echo e(!empty($walikelas->guru->nama_guru) ?
                        $walikelas->guru->nama_guru : '-'); ?></td>
        </tr>
       
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nama_project\resources\views/walikelas/show.blade.php ENDPATH**/ ?>