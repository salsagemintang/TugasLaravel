<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
 integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous"  textColor="white">

<?php $__env->startSection('main'); ?>

<div id="guru">
    <h2>Edit Guru</h2>

    <form action="<?php echo e(url('guru/'.$guru->id.'/update')); ?>" method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="form-group">
        <label for="id" class="control-label">NIP</label>
        <input name="id" type="text" class="form-control" value="<?php echo e($guru->id); ?>">
    </div>

    <div class="form-group">
        <label for="nama_guru" class="control-label">Nama</label>
        <input name="nama_guru" type="text" class="form-control" value="<?php echo e($guru->nama_guru); ?>">
    </div>

    <div class="form-group">
        <label for="tanggal_lahir" class="control-label">Tanggal Lahir</label>
        <input name="tanggal_lahir" type="date" class="form-control" value="<?php echo e($guru->tanggal_lahir); ?>">
    </div>

    <div class="form-group">
        <label for="jenis_kelamin" class="control-label">Jenis Kelamin</label>
        <?php if($guru->jenis_kelamin=="P"): ?>
        <div class="form-check">
            <input class="form-check-input" type="radio" name="jenis_kelamin" id="jenis_kelamin" value="P" checked>
            <label class="form-check-label" for="jenis_kelamin">
            Perempuan
        </label>
    </div>

    <div class="form-check">
            <input class="form-check-input" type="radio" name="jenis_kelamin" id="jenis_kelamin" value="L" checked>
            <label class="form-check-label" for="jenis_kelamin">
            Laki-Laki
        </label>
    </div>
    <?php elseif($guru->jenis_kelamin=="L"): ?>
     <div class="form-check">
            <input class="form-check-input" type="radio" name="jenis_kelamin" id="jenis_kelamin" value="P">
            <label class="form-check-label" for="jenis_kelamin">
            Perempuan
        </label>
     </div>

     <div class="form-check">
            <input class="form-check-input" type="radio" name="jenis_kelamin" id="jenis_kelamin" value="L" checked>
            <label class="form-check-label" for="jenis_kelamin">
            Laki-Laki
        </label>
     </div>
     <?php endif; ?>

     <div class="form-group">
        <label for="fotoGuru" class="control-label">apa aja</label>
        <input name="fotoGuru" type="file" class="form-control" >
    </div>

</div>
    <button type="submit" class="btn btn-primary">Submit</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nama_project\resources\views/guru/edit.blade.php ENDPATH**/ ?>