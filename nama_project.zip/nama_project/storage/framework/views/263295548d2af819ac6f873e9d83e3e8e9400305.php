<?php $__env->startSection('main'); ?>
<div id="guru">
      <h2>Detail Guru</h2>

      <table class="table table-striped">
       <tr>
        <center>
            <img class="rounded" src="<?php echo e(asset('foto/'.$guru->fotoGuru)); ?>" width="300px" height="auto">
        </center>
        </tr>
        <br>
        <tr>
            <th>NIP</th>
            <td><?php echo e($guru->nisn); ?></td>
        </tr>
        <tr>
            <th>Nama</th>
            <td><?php echo e($guru->nama_guru); ?></td>
        </tr>
        <tr>
            <th>Tanggal Lahir</th>
            <td><?php echo e($guru->tanggal_lahir); ?></td>
        </tr>
        <tr>
            <th>Jenis Kelamin</th>
            <td><?php echo e($guru->jenis_kelamin); ?></td>
        </tr>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nama_project\resources\views/guru/show.blade.php ENDPATH**/ ?>