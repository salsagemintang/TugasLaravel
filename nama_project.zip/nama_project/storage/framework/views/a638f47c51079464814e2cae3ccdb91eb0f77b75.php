<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
 integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous"  textColor="white">
 
<?php $__env->startSection('main'); ?>
    <div id="walikelas">
        <h2>Tambah Wali Kelas</h2>

        <form action="<?php echo e(url('walikelas')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="form-group">
        <label for="id" class="control-label">ID Walikelas</label>
        <input name="id" type="text" class="form-control">
    </div>

    <div class="form-group">
        <label for="id_kelas" class="control-label">Nama Kelas</label>
        <select name="id_kelas" class="custom-select" class="form-control">
        <option selected></option>
        <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($k->id); ?>"><?php echo e($k->nama_kelas); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

   <div class="form-group">
        <label for="id_guru" class="control-label">Nama Guru</label>
        <select name="id_guru" class="custom-select" class="form-control">
        <option selected>Guru...</option>
        <?php $__currentLoopData = $guru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($g->id); ?>"><?php echo e($g->nama_guru); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <div class="form-group">
            <label for="avatar">Avatar</label>
            <input type="file" name="avatar" class="form-control">
            </div>
    </div>
    <button type="submit" class="btn btn-primary">Submit</button>
    </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nama_project\resources\views/walikelas/create.blade.php ENDPATH**/ ?>