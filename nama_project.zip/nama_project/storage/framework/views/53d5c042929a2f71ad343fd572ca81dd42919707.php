<?php $__env->startSection('main'); ?>
<div id="register">
    <h2>Form Registrasi</h2>
    <form acction="" method="">
        <table>
            <tr>
                <td>
                    <label for="nama"> Nama </label>
                </td>
                <td>:</td>
                <td>
                    <input type="text" name="" id="">
                </td>
            </tr>
            <tr>
                <td>
                    <label for="nis">NIS </label>
                </td>
                <td>:</td>
                <td>
                    <input type="number" name="" id="">
                </td>
            </tr>
            <tr>
                <td>
                    <label for="kelas"> Kelas </label>
                </td>
                <td>:</td>
                <td>
                    <input type="text" name="" id="">
                </td>
            </tr>
            <tr>
                <td>
                    <label for="jurusan"> Jurusan </label>
                </td>
                <td>:</td>
                <td>
                    <input type="text" name="" id="">
                </td>
            </tr>
            <tr>
                <td>
                    <label for="alamat"> Alamat </label>
                </td>
                <td>:</td>
                <td>
                    <input type="text" name="" id="">
                </td>
            </tr>
            <tr>
                <td></td>
                <td></td>
                <td>
                    <button type="submit">Save</button>
                    <button type="submit">Cancel</button>
                </td>
    </table>
</div><?php /**PATH C:\xampp\htdocs\nama_project\resources\views/pages/register.blade.php ENDPATH**/ ?>