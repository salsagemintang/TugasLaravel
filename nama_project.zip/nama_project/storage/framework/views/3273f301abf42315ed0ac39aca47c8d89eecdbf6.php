<?php $__env->startSection('main'); ?>
<div id="siswa">
      <h2>Nama Siswa</h2>

     <?php if(!empty($siswa_list)): ?>
     <table class="table table-striped">
    <tr>
        <th>NISN</th>
        <th>Nama</th>
        <th>Tanggal Lahir</th>
        <th>Jenis kelamin</th>
        <th>Kelas</th>
        <th>Action</th>
    </tr>

        <tbody>
            <?php $__currentLoopData = $siswa_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                <td><?php echo e($siswa->nisn); ?></td>
                <td><a href="<?php echo e(url('siswa/' . $siswa->id . '/profile')); ?>"><?php echo e($siswa->nama_siswa); ?></a></td>
                <td><?php echo e($siswa->tanggal_lahir); ?></td>
                <td><?php echo e($siswa->jenis_kelamin); ?></td>
                <td><?php echo e(! empty($siswa->kelas->nama_kelas)?
                        $siswa->kelas->nama_kelas : '-'); ?></td>
                <td><a class="btn btn-success btn-sm" href="<?php echo e(url('siswa/' . $siswa->id)); ?>">Detail</a></td>
                <td><a class="btn btn-warning btn-sm" href="<?php echo e(url('siswa/' . $siswa->id . '/edit')); ?>">Edit</a></td>
                <td><a class="btn btn-danger btn-sm" href="<?php echo e(url('siswa/' . $siswa->id . '/delete')); ?>">Delete</a></td>

                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
        
    <?php else: ?>
        <p>Tidak ada data siswa.</p>
    <?php endif; ?>

</div>
  </tbody>
</table>
    <a href="<?php echo e(url('siswa/create')); ?>" class="btn btn-primary">Tambah</a>
    <a href="../public/siswa/cetak_pdf" class="btn btn-primary" target="_blank">Cetak PDF</a>
    <table class='table table-bordered'>
<br>
<br>
<br>
<br>
<br>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
    <div id="footer">
        <p>&copy; 2019 Belajar_Laravel</p>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nama_project\resources\views/siswa/index.blade.php ENDPATH**/ ?>