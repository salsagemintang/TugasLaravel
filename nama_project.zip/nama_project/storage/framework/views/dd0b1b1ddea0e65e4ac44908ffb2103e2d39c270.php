<?php $__env->startSection('main'); ?>
<div id="about">
    <h2>About</h2>
    <p>Sistem ini dibuat sebagai latihan <br>
        untuk mempelajari dasar Laravel.</p>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nama_project\resources\views/pages/about.blade.php ENDPATH**/ ?>