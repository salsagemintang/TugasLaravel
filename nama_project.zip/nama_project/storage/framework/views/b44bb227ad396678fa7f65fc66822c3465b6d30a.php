<?php $__env->startSection('main'); ?>
<div id="walikelas">

     <?php if(!empty($walikelas_list)): ?>
     <table class="table table-striped">
    <tr>
        <th>ID</th>
        <th>Nama Guru</th>
        <th>Nama Kelas</th>
        <th>Admin</th>
    </tr>

        <tbody>
            <?php $__currentLoopData = $walikelas_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $walikelas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                <td><?php echo e($walikelas->id); ?></td>
                <!--<td><a href="<?php echo e(url('walikelas/' . $walikelas->id . '/profile')); ?>"><?php echo e($walikelas->nama_walikelas); ?></a></td>-->
                <td><?php echo e(! empty($walikelas->guru->nama_guru)?
                        $walikelas->guru->nama_guru : '-'); ?></td>
                <td><?php echo e(! empty($walikelas->kelas->nama_kelas)?
                        $walikelas->kelas->nama_kelas : '-'); ?></td>
                <td><a class="btn btn-success btn-sm" href="<?php echo e(url('walikelas/' . $walikelas->id)); ?>">Detail</a></td>
                <td><a class="btn btn-warning btn-sm" href="<?php echo e(url('walikelas/' . $walikelas . '/edit')); ?>">Edit</a></td>
                <td><a class="btn btn-danger btn-sm" href="<?php echo e(url('walikelas/' . $walikelas->id . '/delete')); ?>">Delete</a></td>

                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
        
    <?php else: ?>
        <p>Tidak ada data wali kelas.</p>
    <?php endif; ?>

</div>
  </tbody>
</table>
    <a href="<?php echo e(url('walikelas/create')); ?>" class="btn btn-primary">Tambah</a>
<br>
<br>
<br>
<br>
<br>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
    <div id="footer">
        <p>&copy; 2019 Belajar_Laravel</p>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nama_project\resources\views/walikelas/index.blade.php ENDPATH**/ ?>