<?php $__env->startSection('main'); ?>
<div id="siswa">
<h2>Siswa</h2>

<?php if(!empty($siswa_list)): ?>
<table class="table table-striped">
  <thead>
    <tr>
      <th scope="col"><h3>NISN</h3></th>
      <th scope="col"><h3>Nama</h3></th>
      <th scope="col"><h3>Tgl Lahir</h3></th>
      <th scope="col"><h3>JK</h3></th>
      <th scope="col"><h3>Kelas</h3></th>

    </tr>
  </thead>
  <tbody>
      <?php $__currentLoopData = $siswa_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td><?php echo e($siswa->nisn); ?></td>
        <td><?php echo e($siswa->nama_siswa); ?></a></td>
        <td><?php echo e($siswa->tanggal_lahir); ?></td>
        <td><?php echo e($siswa->jenis_kelamin); ?></td>
        <td><?php echo e(! empty($siswa->kelas->nama_kelas) ?
              $siswa->kelas->nama_kelas : '-'); ?></td>



      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
      <?php else: ?>
          <p>Tidak ada data siswa</p>
      <?php endif; ?>

    </div>
  <?php $__env->stopSection(); ?>


<?php $__env->startSection('footer'); ?>
    <div id="footer">
        <p>&copy; 2019 Belajar_Laravel</p>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('temppdf', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nama_project\resources\views/siswa/cetak_pdf.blade.php ENDPATH**/ ?>