@extends('template')

@section('main')

<div id="homepage">
    <h2>Homepage</h2>
    <p>Selamat Belajar Laravel</p>
</div>

@stop 

@section('footer')
    <div id="footer">
        <p>&copy; 2019 Belajar_Laravel.ev</p>
    </div>
@stop
