@extends('template')

@section('main')
<div id="about">
    <h2>About</h2>
    <p>Sistem ini dibuat sebagai latihan <br>
        untuk mempelajari dasar Laravel.</p>
</div>
@stop
